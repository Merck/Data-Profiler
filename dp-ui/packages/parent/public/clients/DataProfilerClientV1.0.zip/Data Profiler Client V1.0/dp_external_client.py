import requests
import json
import pandas as pd
import numpy as np
from scipy.stats import variation, kurtosis, skew
from termcolor import colored
from datetime import datetime
from pytz import timezone
import sys
import os
from urllib.parse import quote_plus


def element_fmt(input):
    if (str(input).find("/") > 0):
        return quote_plus(str(input))
    else:
        return str(input)

def validate(value, possible_values, value_name):
    if value == "" or value is None:
        dataset_error = "Dataset not specified"
        print(colored(
            "ERROR! " + value_name + " name [" + str(value) + "] not specified", "red"))
        return False

    elif value not in possible_values:
        dataset_error = "Dataset name not valid"
        print(colored(
            "ERROR! " + value_name + " name [" + str(value) + "] not valid", "red"))
        return False

    return True

def requestResponsePrint(response, total_run_time):
    if str(response) == "<Response [200]>":
        print(colored(
            "\nDownload successful! Request completed in " + str(total_run_time), "green"))

    elif str(response) == "<Response [401]>":
        print(colored(
            "\nERROR! Unauthorized. Your credentials are either invalid or expired.", "red"))

    elif str(response) == "<Response [403]>":
        print(colored("\nERROR! You don't have permission to access the resource you're trying to. If you believe this is in error, please contact the Data Profiler Team.", "red"))

    elif str(response == "<Response [403]>"):
        print(colored("\nERROR! The request had an error due to programming errors or cluster component downtime. Please try again, and contact the Data Profiler Team if the problem persists.", "red"))


class Column():
    def __init__(self, environment, dataset_name, table_name, column_name, filters={}):
        self.column_name = column_name
        self.table_name = table_name
        self.dataset_name = dataset_name
        self.env = environment
        self.filters = filters

        validated = self.validateData()

        self.metadata = self.getColumnMetadata()

        if self.filters != {}:
            validate_filter = self.validateFilters()
            if validate_filter==False:
                print (colored("ERROR: this is not valid input", "red"))

        if validated==False:
            print (colored("ERROR: this is not valid input", "red"))

    ##### data about the column itself #####
    def getColumnMetadata(self):
        url = self.env.url + '/api/v1/columns/{}/{}'.format(self.dataset_name, self.table_name)
        response = requests.get(url, headers=self.env.header)

        return response.json()[self.column_name]

    ##### setting filters for listing columns counts #####
    def setFilters(self, filters):
        self.filters = filters

        self.validateData()

    ##### retrieving data stored within the column metadata #####
    def getColumnDataType(self):
        return self.metadata['data_type']

    def getValueCount(self):
        return self.metadata['num_values']

    def getUniqueValueCount(self):
        return self.metadata['num_unique_values']

    def getVisibility(self):
        return self.metadata['visibility']

    ##### lists a dictionary of column counts with the structures as follows #####
    ##### [{'value':'value1', 'count':'count1'},...]                         #####
    def listColumnCounts(self):
        ## filters do not work for this endpoints
        post_data = json.dumps({
            "dataset": self.dataset_name,
            "table": self.table_name,
            "column": self.column_name,
            "limit": 0, 
            "sort": "CNT_DESC"
        })
        url = self.env.url + '/api/experimental/colCounts'
        response = requests.post(url, headers=self.env.header, data=post_data)

        text_data = response.text
        text_data = text_data[:-1]
        json_data = json.loads(text_data)

        return json_data 

    ##### Lists of valid datasets, tables, and columns #####
    def validDatasets(self):
        return self.env.getDatasetList()

    def validTables(self):
        url = self.env.url + '/api/v1/tables/{}'.format(self.dataset_name)
        response = requests.get(url, headers=self.env.header)

        return list(response.json().keys())

    def validColumns(self):
        url = self.env.url + '/api/v1/columns/{}/{}'.format(self.dataset_name, self.table_name)
        response = requests.get(url, headers=self.env.header)

        return list(response.json().keys())

    ##### validates the dataset, table, and column specified on initialization #####
    def validateData(self):
        valid_datasets = self.validDatasets()
        dataset_valid = validate(self.dataset_name, valid_datasets, "Dataset")

        if dataset_valid:
            valid_tables = self.validTables()
            table_valid = validate(self.table_name, valid_tables, "Table")

            if table_valid:
                valid_columns = self.validColumns()
                column_valid = validate(self.column_name, self.validColumns(), "Column")

        return dataset_valid & table_valid & column_valid

    ##### validates the filters the user can choose to set #####
    def validateFilters(self):

        if self.filters != {}:
            filter_keys = [x for x in self.filters]

            for key in filter_keys:
                valid_filter = validate(key, self.validColumns(), "Filter Column")
                if valid_filter==False:
                    return False

        return True

    def getNAscount(self,blanks_type = {'',' ','-',None, np.nan}):
        ValCount = self.listColumnCounts()
        cnt_all = 0
        for vc in ValCount:
            if vc['value'] in blanks_type:
                cnt_all += vc['count']
        
        return cnt_all
        

class Table():
    def __init__(self, environment, dataset_name, table_name, filters={}):
        self.table_name = table_name
        self.dataset_name = dataset_name
        self.env = environment
        self.filters = filters

        validated = self.validateData()
        if validated==False:
            print (colored("ERROR: The input data is not valid", "red"))

        self.table_info = self.getTableInfo()
        self.metadata = self.getTableMetadata()

        if self.filters != {}:
            validated_filters = validateFilters()
            if validated_filters==False:
                print (colored("ERROR: The input data is not valid", "red"))

    #### get specific information about the inside of the table #####
    def getTableInfo(self):
        url = self.env.url + '/api/v1/columns/{}/{}'.format(self.dataset_name, self.table_name)
        response = requests.get(url, headers=self.env.header)

        return response.json()

    ##### get metadata about the table #####
    def getTableMetadata(self):
        url = self.env.url + '/api/v1/tables/{}'.format(self.dataset_name)
        response = requests.get(url, headers=self.env.header)

        return response.json()[self.table_name]

    ##### set filters for loading table rows #####
    def setFilters(self, filters):
        self.filters = filters

        self.validateFilters()

    ##### get functions to access the information in the table #####
    def getColumnList(self):
        return list(self.table_info.keys())

    def getColumnCount(self):
        return len(self.getColumnList())

    ##### get functions to access the table metadata #####
    def getUploadDate(self):
        epoch_time = float(self.metadata['load_time'])/1000
        return datetime.fromtimestamp(epoch_time)
    
    def getUpdateDate(self):
        epoch_time = float(self.metadata['update_time'])/1000
        return datetime.fromtimestamp(epoch_time)

    def getVisibility(self):
        return self.metadata["visibility"]

    def getTableCount(self):
        return self.metadata["num_tables"]

    def getColumnCount(self):
        return self.metadata["num_columns"]

    def getValueCount(self):
        return self.metadata["num_values"]

    def getPullTimestamp(self):
        epoch_time = float(self.metadata["timestamp"])/1000
        return datetime.fromtimestamp(epoch_time)

    ##### format data for post requests #####
    def getPostData(self):
        post_data = json.dumps({
                "dataset": self.dataset_name,
                "table": self.table_name,
                "sort": "CNT_DESC",
                "filters": self.filters,
                "limit":0
            })

        return post_data

    ##### load the rows from the table #####
    def loadRows(self):
        print((colored("Note: This endpoint is experimental - expect longer load times for larger datasets", "cyan")))

        if self.filters == {}:
            print("\nDownloading ALL ROWS: ", self.dataset_name,
                ",", self.table_name, "...")
        else:
            print("\nDownloading FILTERED TABLE: ", self.dataset_name, "|",
                  self.table_name, "\nFilter(s) applied: ", self.filters, "...")

        try:
            url = self.env.url + '/api/v1/rows'

            post_data = self.getPostData()

            # Time post request
            start_time = datetime.now(timezone('US/Eastern'))
            response = requests.post(
                url, headers=self.env.header, data=post_data)
            total_run_time = str(datetime.now(
                timezone('US/Eastern')) - start_time)
            requestResponsePrint(response, total_run_time)

            # Convert to text to remove extra "$" character
            response.encoding = 'utf-8'
            text_data = response.text
            text_data = text_data[:-1]

            if len(text_data) < 2:
                print(colored("Data request empty!", "red"))
                ## returns an empty dataframe with the column structure of the table itself
                df = pd.DataFrame(columns=self.getColumnList())
            else:
                json_data = json.loads(text_data)
                df = pd.DataFrame(json_data)

            return df

        except ValueError:  # includes simplejson.decoder.JSONDecodeError
            print(
                colored("\nError - check response message or text to json parser.", "red"))
            return None

    ## get match locations for a given substring in a given column
    ## returns: list of match locations
    def getSubstringValueMatches(self, substring, column):
        ## data for substring post request
        post_data = json.dumps({
            "begins_with": False,
            "substring_match": True,
            "term": [substring],
            "dataset": self.dataset_name,
            "table": self.table_name,
            "column": column
        })
        ## call endpoint to retrieve location responses
        value_search_endpoint = self.env.url + '/search'
        response = requests.post(value_search_endpoint, headers=self.env.header, data=post_data)
        response_str = response.text

        try:
            response_list = json.loads(response_str)
            return response_list
        except:
            print (colored("There were no value results for your query", "red"))
            return []

    ## loads all the rows in a given table that match the provided substring filters
    ## these filters are structured like {'column':['subtring1',...],...} just
    ## like the ordinary filters
    def loadRowsWithSubstringMatches(self, substring_filters):
        filters = {}
        for col in substring_filters:
            vals = []
            for filt in substring_filters[col]:
                response_list = self.getSubstringValueMatches(filt, col)
                for r in response_list:
                    vals.append(r["value"])
                    
            filters[col] = vals

        self.setFilters(filters)
        df = self.loadRows()

        return df

    ## searches for all values within a given range in a given column
    ## returns: a dataframe of all the rows that match (or none if error)
    def loadRowsInRange(self, min_val, max_val, column):
        ## calculate the number of sig figs in a decimal
        ## or return 0 for integer values
        def sigFigs(val):
            split_val = str(val).split(".")
            if len(split_val) > 1:
                return len(split_val[1])
            else:
                return 0
        
        ## formats input value for substring matching
        def formatVal(val):
            substring = str(val)
            if "." in substring:
                substring = substring.strip("0")
                if substring.endswith("."):
                    substring = substring[:-1]

            return substring

        if self.validateRangeInput(min_val, max_val, column):
            ## format number of sig figs and value to increment
            if "." in str(min_val) or "." in str(max_val):
                sig_figs = max(sigFigs(min_val), sigFigs(max_val))
                incre = float(1/(10**sig_figs))
            else:

                sig_figs = 0
                incre = 1

            cur_val = round(float(min_val), sig_figs)
            filters = {column:[]}

            ## finds all the values that match the substring and
            ## exist in the table
            while cur_val < float(max_val):
                response_list = self.getSubstringValueMatches(formatVal(cur_val), column)
                ## go through potential matches and validate that they fall within the range
                for potential in response_list:
                    pot_val = potential["value"]
                    if float(pot_val) >= float(min_val) and float(pot_val) < float(max_val) and potential["count"] > 0:
                        if column in filters:
                            filters[column].append(pot_val)

                cur_val += incre
                cur_val = round(cur_val, sig_figs)

            ## pull all the rows that match the substring filters
            self.setFilters(filters)
            match_df = self.loadRows()

            return match_df

        else:
            return None
            
    def getNAscount(self,blanks_type = {'',' ','-',None,np.nan}):
        df = self.loadRows()
        blank_vals = dict( df.apply(lambda x: x[x.isin(blanks_type)].shape[0],0) ) 
        return blank_vals 

    # Current return is dataframe can be converted in dictionary as well
    def getQuantiles(self,qvals = [0,.25, .5, .75,1], columns = []):
        df = self.loadRows()
        Tableinfo = self.getTableInfo()

        if columns != []:
            for column in columns:
                try:
                    if Tableinfo[column]['data_type'] not in {'integer','long','float','double'}:
                        print(colored("\nError - Select columns with data type as integer, float, double or long.", "red"))
                        return None  
                except KeyError:
                    print(colored("\nError - Column {} doesn't exist in table.".format(column), "red"))
                    return None
        else:
            for column in Tableinfo:
                if Tableinfo[column]['data_type'] in {'integer','long','float','double'}: #check for float"
                    columns.append(column)


        df[columns] = df[columns].apply( lambda x: pd.to_numeric(x,errors = 'coerce'), axis = 0)
        # print('dtypes',df.dtypes)
        return pd.DataFrame(df[columns].quantile(qvals)) 


    def getDescriptiveStats(self,columns= [], signi_fig= 2):
        df = self.loadRows()
        # Descriptive statistics like mean, mode, standard deviation, 
        # sum, median absolute deviation, coefficient of variation, kurtosis, 
        # skewness
        Tableinfo = self.getTableInfo()

        if columns != []:
            for column in columns:
                try:
                    if Tableinfo[column]['data_type'] not in {'integer','long','float', 'double'}:
                        print(colored("\nError - Select columns with data type as integer, float, double or long.", "red"))
                        return None  
                except KeyError:
                    print(colored("\nError - Column {} doesn't exist in table.".format(column), "red"))
                    return None
        else:
            for column in Tableinfo:
                if Tableinfo[column]['data_type'] in {'integer','long','float','double'}:
                    columns.append(column)
        df[columns] = df[columns].apply( lambda x: pd.to_numeric(x,errors = 'coerce'), axis = 0)

        Dstats = {}
        Dstats['mean'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].mean()) ]
        Dstats['median'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].median()) ]
        Dstats['mode'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].mode()) ]
        Dstats['sum'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].sum()) ]
        Dstats['std'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].std()) ] 
        Dstats['mad'] = [round(x,signi_fig) if isinstance(x, float)  else np.nan for x in list(df[columns].mad()) ]
        Dstats['variation'] = df[columns].apply(lambda x: np.round(variation(x),signi_fig), axis = 0)
        Dstats['kurtosis'] = df[columns].apply(lambda x: np.round(kurtosis(x),signi_fig), axis = 0)
        Dstats['skewness'] = df[columns].apply(lambda x: np.round(skew(x),signi_fig), axis = 0)

        return pd.DataFrame(Dstats)

    ##### get list of valid datasets and tables for verification of input #####
    def validDatasets(self):
        valid_datasets = self.env.getDatasetList()

        return valid_datasets

    def validTables(self):
        url = self.env.url + '/api/v1/tables/{}'.format(self.dataset_name)
        response = requests.get(url, headers=self.env.header)
        valid_tables = list(response.json().keys())

        return valid_tables

    ##### validate the dataset and table inputs #####
    def validateData(self):
        valid_datasets = self.validDatasets()
        dataset_valid = validate(self.dataset_name, valid_datasets, "Dataset")

        if dataset_valid:
            valid_tables = self.validTables()
            table_valid = validate(self.table_name, valid_tables, "Table")

        return dataset_valid & table_valid

    ##### validate the columns chosen for filtering #####
    def validateFilters(self):
        valid_columns = self.getColumnList()

        if self.filters != {}:
            filter_keys = [x for x in self.filters]

            for key in filter_keys:
                valid_filter = validate(key, valid_columns, "Filter Column")
                if valid_filter == False:
                    return False

        return True
    
    ## validate that the inputs into the range search query are valid
    ## returns: validity boolean
    def validateRangeInput(self, min_val, max_val, column):
        try:
            float(min_val)
            float(max_val)
        except:
            print (colored("Min and max values must be integers or floats","red"))
            return False

        if column in self.getColumnList():
            return True
        else:
            print (colored("Column must be valid column in table", "red"))
            return False



class Dataset():

    def __init__(self, environment, dataset_name):
        self.dataset_name = dataset_name
        self.env = environment

        self.validateData()

        self.dataset_info = self.getDatasetInfo()
        self.metadata = self.getDatasetMetadata()

    def getDatasetInfo(self):
        url = self.env.url + '/api/v1/tables/{}'.format(self.dataset_name)
        response = requests.get(url, headers=self.env.header)

        return response.json()

    def getDatasetMetadata(self):
        url = self.env.url + '/api/v1/datasets'
        response = requests.get(url, headers=self.env.header)
        
        return response.json()[self.dataset_name]

    def getTableList(self):
        return list(self.dataset_info.keys())

    def getUploadDate(self):
        epoch_time = float(self.metadata['load_time'])/1000
        return datetime.fromtimestamp(epoch_time)
    
    def getUpdateDate(self):
        epoch_time = float(self.metadata['update_time'])/1000
        return datetime.fromtimestamp(epoch_time)

    def getVisibility(self):
        return self.metadata["visibility"]

    def getTableCount(self):
        return self.metadata["num_tables"]

    def getColumnCount(self):
        return self.metadata["num_columns"]

    def getValueCount(self):
        return self.metadata["num_values"]

    def getPullTimestamp(self):
        epoch_time = float(self.metadata["timestamp"])/1000
        return datetime.fromtimestamp(epoch_time)

    def validateData(self):
        valid_datasets = self.env.getDatasetList()
        dataset_valid = validate(self.dataset_name, valid_datasets, "Dataset")
        return dataset_valid
    
    def loadTable(self, table_name):
        print("\nDownloading ALL ROWS: ", self.dataset_name, ",", table_name, "...")

        try:
            url = self.env.url + '/api/v1/rows'

            post_data = json.dumps({
                    "dataset": self.dataset_name,
                    "table": table_name,
                    "limit": 0, 
                    "sort": "CNT_DESC"
                })

            # Time post request
            start_time = datetime.now(timezone('US/Eastern'))
            response = requests.post(
                url, headers=self.env.header, data=post_data)
            total_run_time = str(datetime.now(
                timezone('US/Eastern')) - start_time)
            requestResponsePrint(response, total_run_time)

            # Convert to text to remove extra "$" character
            response.encoding = 'utf-8'
            text_data = response.text
            text_data = text_data[:-1]

            if len(text_data) < 2:
                print(colored("Data request empty!", "red"))
                ## returns an empty dataframe with the column structure of the table itself
                df = pd.DataFrame(columns=self.getColumnList())
            else:
                json_data = json.loads(text_data)
                df = pd.DataFrame(json_data)

            return df

        except ValueError:  # includes simplejson.decoder.JSONDecodeError
            print(
                colored("\nError - check response message or text to json parser.", "red"))
            return None

    def importDataset(self):
        print((colored("Note: This endpoint is experimental - expect longer load times for larger datasets", "cyan")))
        tables = self.getTableList()
        all_tables = {}
        for table in tables:
            all_tables[table] = self.loadTable(table)
        
        return all_tables

class Environment():
    def __init__(self, api_key, url):
        self.api_key = api_key
        self.url = url
        self.header = {
            "Content-Type": "application/json",
            "X-Api-Key": self.api_key,
            "Accept": "application/json"
        }

        self.env_info = self.getEnvironmentInfo()

    ##### gets all specific information about the contents of the environment#####
    def getEnvironmentInfo(self):
        url = self.url + '/api/v1/datasets'
        try:
            response = requests.get(url, headers=self.header)
            return response.json()
        except:
            print (colored("ERROR: Could not connect to DP. Check that you are connected to the VPN before retrying", "red"))
            return None

    ##### gets a list of all the datasets in the env available to the user #####
    def getDatasetList(self):
        return list(self.env_info.keys())

    ##### the number of datasets in the environment #####
    def getDatasetCount(self):
        return len(self.getDatasetList())


class Omnisearch():
    def __init__(self, environment, search_str):
        self.env = environment
        self.search_str = search_str
        self.search_str_lower = search_str.lower()

        self.postdata = json.dumps({
            "term": [self.search_str],
            "begins_with": "True"
        })

        ## these will be parsed as they are called by the user ##
        self.value_matches = None
        self.column_matches = None
        self.table_matches = None
        self.dataset_matches = None
        self.all_matches = None

    ## get value matches
    def getValueMatches(self):
        if self.value_matches is None:
            value_search_endpoint = self.env.url + '/api/v1/search'
            response = requests.post(value_search_endpoint, headers=self.env.header, data=self.postdata)
            response_str = str(response.text)[:-1]

            try:
                response_list = json.loads(response_str)
                setattr(self, 'value_matches', response_list)
            except:
                print (colored("There were no value results for your query", "red"))
                setattr(self, 'value_matches', [])
                return []

        return self.value_matches

    ## get number of values in table that match
    def getNumValueMatches(self):
        if self.value_matches:
            return len(self.value_matches)
        else:
            return len(self.getValueMatches())

    ## get dataset matches
    def getDatasetMatches(self):
        if self.dataset_matches is None:
            matches = []
            datasets = self.env.getDatasetList()
            for dataset in datasets:
                lower_dataset = dataset.lower()
                if lower_dataset.startswith(self.search_str_lower):
                    matches.append({'dataset':dataset})

            setattr(self, 'dataset_matches', matches)
            if matches == []:
                print (colored("There were no table results for your query", "red"))

        return self.dataset_matches

    ## get number of datasets that match
    def getNumDatasetMatches(self):
        if self.dataset_matches:
            return len(self.dataset_matches)
        else:
            return len(self.getDatasetMatches())
    
    ## get table matches
    def getTableMatches(self):
        if self.table_matches is None:
            table_search_endpoint =self.env.url + '/tables/search'
            response = requests.post(table_search_endpoint, headers=self.env.header, data=self.postdata)
            response_str = str(response.text)
            try:
                response_list = json.loads(response_str)
                setattr(self, 'table_matches', response_list)
            except:
                print (colored("There were no table results for your query", "red"))
                setattr(self, 'table_matches', [])

        return self.table_matches

    ## get number of tables that match
    def getNumTableMatches(self):
        if self.table_matches:
            return len(self.table_matches)
        else:
            return len(self.getTableMatches())
            
    ## get column matches
    def getColumnMatches(self):
        if self.column_matches is None:
            column_search_endpoint =self.env.url + '/columns/search'
            response = requests.post(column_search_endpoint, headers=self.env.header, data=self.postdata)
            response_str = str(response.text)
            try:
                response_list = json.loads(response_str)
                setattr(self, 'column_matches', response_list)
                if response_list == []:
                    print (colored("There were no column results for your query", "red"))
            except:
                print (colored("There were no column results for your query", "red"))
                setattr(self, 'column_matches', [])

        return self.column_matches

    ## get number of columns that match
    def getNumColumnMatches(self):
        if self.column_matches:
            return len(self.column_matches)
        else:
            return len(self.getColumnMatches())

    ## get all matches
    def getAllMatches(self):
        if self.all_matches is None:
            values = self.getValueMatches()
            columns = self.getColumnMatches()
            tables = self.getTableMatches()
            datasets = self.getDatasetMatches()

            all_matches = {
                "values": values,
                "columns": columns,
                "tables": tables,
                "datasets": datasets
            }
            setattr(self, "all_matches", all_matches)
        
        return self.all_matches

    ## get the number of all matches
    def getNumAllMatches(self):
        if self.all_matches is None:
            self.getAllMatches()

        num_matches = len(self.value_matches) + len(self.column_matches) + len(self.table_matches) + len(self.dataset_matches)
        
        return num_matches