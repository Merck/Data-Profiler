# dp_external_client

This client is a link to the data profiler API.

```
import dp_external_client

user_client = dp_external_client.Environment('YOURAPIKEY','https://YOURENVIRONMENT-api.dataprofiler.merck.com')
```

# Documentation

If you have questions about functionality, please refer to the documentation:
https://share.merck.com/display/TRJ/DP+API+Python+Wrapper+Documentation

### Contributing

1) Clone the branch to your machine. Use the --depth flag to improve performance
```
git clone -–depth 1 ssh://git@stash.merck.com/tar/tarjan-complete.git
```

2) Create a branch
```
git checkout -b feature/description-of-your-feature
```

3) Add files and commit on your branch

4) Push your branch
```
git push -u origin feature/description-of-your-feature
```

5) Create a pull request
```
https://stash.merck.com/projects/TAR/repos/tarjan-complete/branches
```

6) In addition to the default reviewers, add Noelle Villa and Allison Shulenberger

### Running local tests

The first time you run tests, you'll need to login to our container registry.
```
docker login container-registry.tarjan.merck.com
user: docker
password: docker
```


You'll also need to increase your Docker Memory to allow the MiniAccumulo cluster to run. 
```
Docker > Settings/Preferences > Resources > Memory > Increase to at least 8GB 
```


To run the tests locally
```
docker-compose -f test/build.yml run build ./build.py --api-copy
docker-compose -f test/test-runner-compose.yml up --build
docker-compose -f test/test-runner-compose.yml run ext_client python3 test/test.py
docker-compose -f test/test-runner-compose.yml down
```

If you make changes and want to run the tests again
```
docker-compose -f test/test-runner-compose.yml build ext_client && docker-compose -f test/test-runner-compose.yml run ext_client python3 test/test.py
```