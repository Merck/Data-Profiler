#!/usr/bin/env python

from distutils.core import setup

setup(name='dp_external_client',
      version='1.0',
      description='Python Wrapper for the Data Profiler API',
      author='Computer Sciences Team',
      scripts=['dp_external_client.py'],
      url='https://stash.merck.com/projects/TAR/repos/tarjan-complete/browse/dp_external_client',
      py_modules=['dp_external_client'],
     )