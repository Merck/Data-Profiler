# dp_external_client

This client is a link to the data profiler API.

```
import dp_external_client

user_client = dp_external_client.Environment('YOURAPIKEY','https://dataprofiler.merck.com/api')
```

Contact Noelle Villa or Andrew Adelson with questions
